package com.example.sporthelper.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.sporthelper.databinding.FragmentNutritionBinding;
import com.example.sporthelper.model.NutritionLog;
import com.example.sporthelper.viewmodel.NutritionViewModel;
import com.example.sporthelper.adapter.NutritionAdapter;
import java.util.List;

public class NutritionFragment extends Fragment {
    private FragmentNutritionBinding binding;
    private NutritionViewModel nutritionViewModel;
    private NutritionAdapter nutritionAdapter;
    private Long currentUserId = 1L;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // ВРЕМЕННОЕ РЕШЕНИЕ
        View view = inflater.inflate(com.example.sporthelper.R.layout.fragment_nutrition, container, false);
        binding = FragmentNutritionBinding.bind(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViewModels();
        setupRecyclerView();
        setupUI();
        loadNutritionLogs();
    }

    private void initViewModels() {
        nutritionViewModel = new ViewModelProvider(requireActivity()).get(NutritionViewModel.class);
    }

    private void setupRecyclerView() {
        nutritionAdapter = new NutritionAdapter(null);
        binding.nutritionRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.nutritionRecyclerView.setAdapter(nutritionAdapter);
    }

    private void setupUI() {
        binding.refreshButton.setOnClickListener(v -> {
            loadNutritionLogs();
            Toast.makeText(getContext(), "Обновление...", Toast.LENGTH_SHORT).show();
        });

        binding.analyzePhotoButton.setOnClickListener(v -> analyzeFoodPhoto());
        binding.addNutritionButton.setOnClickListener(v -> showAddNutritionDialog());
    }

    private void loadNutritionLogs() {
        String today = java.time.LocalDate.now().toString();

        nutritionViewModel.loadNutritionLogs(currentUserId, today);
        nutritionViewModel.getNutritionLogs().observe(getViewLifecycleOwner(), resource -> {
            if (resource != null && resource.data != null) {
                List<NutritionLog> logs = resource.data;
                nutritionAdapter.updateNutritionLogs(logs);
                showEmptyState(logs.isEmpty());
            }
        });
    }

    private void analyzeFoodPhoto() {
        Toast.makeText(getContext(), "Анализ фото еды...", Toast.LENGTH_SHORT).show();
    }

    private void showAddNutritionDialog() {
        Toast.makeText(getContext(), "Добавить питание", Toast.LENGTH_SHORT).show();
    }

    private void showEmptyState(boolean show) {
        binding.emptyState.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.nutritionRecyclerView.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
