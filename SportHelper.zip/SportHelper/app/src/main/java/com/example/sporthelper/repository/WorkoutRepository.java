package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Resource;
import com.example.sporthelper.model.Workout;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import okhttp3.Request;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkoutRepository extends BaseRepository {
    private ExecutorService executor = Executors.newFixedThreadPool(2);
    private Gson gson = new Gson();

    // Добавляем конструктор с Context
    public WorkoutRepository(Context context) {
        super(context);
    }

    public LiveData<Resource<List<Workout>>> getWorkoutsByUser(Long userId) {
        MutableLiveData<Resource<List<Workout>>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "workout_logs?user_id=eq." + userId + "&select=*";
                Request request = createSupabaseRequest(endpoint, "GET", null);
                String response = executeRequest(request);

                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                List<Workout> workouts = new ArrayList<>();

                for (int i = 0; i < jsonArray.size(); i++) {
                    JsonObject workoutObj = jsonArray.get(i).getAsJsonObject();
                    Workout workout = new Workout();
                    workout.setId(workoutObj.get("id").getAsLong());
                    workout.setUserId(workoutObj.get("user_id").getAsLong());
                    workout.setWorkoutName(workoutObj.get("workout_name").getAsString());
                    workout.setWorkoutDate(workoutObj.get("workout_date").getAsString());
                    workout.setDurationMinutes(workoutObj.get("duration_minutes").getAsInt());
                    workout.setCaloriesBurned(workoutObj.get("calories_burned").getAsInt());

                    if (workoutObj.has("notes") && !workoutObj.get("notes").isJsonNull()) {
                        workout.setNotes(workoutObj.get("notes").getAsString());
                    }

                    workouts.add(workout);
                }

                result.postValue(Resource.success(workouts));

            } catch (Exception e) {
                Log.e("WorkoutRepository", "Ошибка загрузки тренировок: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка загрузки: " + e.getMessage(), createMockWorkouts(userId)));
            }
        });

        return result;
    }

    private List<Workout> createMockWorkouts(Long userId) {
        List<Workout> workouts = new ArrayList<>();

        workouts.add(new Workout(
                1L, userId, "Силовая тренировка",
                "2024-01-15", 60, 450, "Отличная тренировка"
        ));

        workouts.add(new Workout(
                2L, userId, "Кардио",
                "2024-01-14", 45, 350, "Беговая дорожка + велосипед"
        ));

        return workouts;
    }
}
