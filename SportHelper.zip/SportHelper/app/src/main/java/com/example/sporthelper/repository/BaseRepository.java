package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class BaseRepository {
    protected static String SUPABASE_URL;
    protected static String SUPABASE_KEY;
    protected static String SUPABASE_REST_URL;

    protected OkHttpClient client;
    protected Gson gson;

    public BaseRepository(Context context) {
        // Получаем ключи из BuildConfig
        SUPABASE_URL = "https://rlgcuhexgjvvqogolmnp.supabase.co";
        SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJsZ2N1aGV4Z2p2dnFvZ29sbW5wIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0ODU0ODYsImV4cCI6MjA3OTA2MTQ4Nn0.eoQofOV4-9NlQwmrJ6hSytb_Ch4lMTrgnly5d4G-Yvo";
        SUPABASE_REST_URL = SUPABASE_URL + "/rest/v1/";

        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new Gson();
    }

    protected Request createSupabaseRequest(String endpoint, String method, JsonObject data) {
        RequestBody body = null;
        if (data != null) {
            body = RequestBody.create(data.toString(), MediaType.parse("application/json"));
        }

        Request.Builder requestBuilder = new Request.Builder()
                .url(SUPABASE_REST_URL + endpoint)
                .header("apikey", SUPABASE_KEY)
                .header("Authorization", "Bearer " + SUPABASE_KEY)
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation");

        if ("POST".equals(method) || "PUT".equals(method) || "PATCH".equals(method)) {
            requestBuilder.method(method, body);
        } else {
            requestBuilder.method(method, null);
        }

        return requestBuilder.build();
    }

    protected String executeRequest(Request request) throws IOException {
        Response response = null;
        try {
            response = client.newCall(request).execute();
            Log.d("BaseRepository", "HTTP код: " + response.code());

            if (response.isSuccessful() && response.body() != null) {
                String responseBody = response.body().string();
                Log.d("BaseRepository", "Успешный ответ: " + responseBody);
                return responseBody;
            } else {
                String errorBody = response.body() != null ? response.body().string() : "No error body";
                String errorMessage = "HTTP " + response.code() + ": " + response.message() + " - " + errorBody;
                Log.e("BaseRepository", errorMessage);
                throw new IOException(errorMessage);
            }
        } catch (Exception e) {
            Log.e("BaseRepository", "Ошибка выполнения запроса: " + e.getMessage(), e);
            throw new IOException("Ошибка сети: " + e.getMessage(), e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
    }
}
