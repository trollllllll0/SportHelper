package com.example.sporthelper.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.sporthelper.R;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;

public class ProfileActivity extends AppCompatActivity {
    private Profile currentUser;
    private SharedPreferencesManager prefsManager;

    private TextView usernameText, emailText, fitnessLevelText, weightText, heightText;
    private Button editProfileButton, logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        prefsManager = SharedPreferencesManager.getInstance(this);

        initViews();
        loadUserData();
        setupUI();
    }

    private void initViews() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Профиль");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        usernameText = findViewById(R.id.usernameText);
        emailText = findViewById(R.id.emailText);
        fitnessLevelText = findViewById(R.id.fitnessLevelText);
        weightText = findViewById(R.id.weightText);
        heightText = findViewById(R.id.heightText);
        editProfileButton = findViewById(R.id.editProfileButton);
        logoutButton = findViewById(R.id.logoutButton);
    }

    private void loadUserData() {
        // Получаем профиль из Intent или из SharedPreferences
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("profile")) {
            currentUser = (Profile) intent.getSerializableExtra("profile");
        } else {
            currentUser = prefsManager.getUserProfile();
        }

        if (currentUser == null) {
            Toast.makeText(this, "Ошибка загрузки профиля", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        updateUI();
    }

    private void updateUI() {
        usernameText.setText(currentUser.getUsername() != null ? currentUser.getUsername() : "Не указано");
        emailText.setText(currentUser.getEmail() != null ? currentUser.getEmail() : "Не указано");

        String fitnessLevel = getFitnessLevelDisplayName(currentUser.getFitnessLevel());
        fitnessLevelText.setText(fitnessLevel);

        weightText.setText(currentUser.getWeight() != null ? currentUser.getWeight() + " кг" : "Не указано");
        heightText.setText(currentUser.getHeight() != null ? currentUser.getHeight() + " см" : "Не указано");
    }

    private void setupUI() {
        editProfileButton.setOnClickListener(v -> {
            Toast.makeText(this, "Редактирование профиля в разработке", Toast.LENGTH_SHORT).show();
        });

        logoutButton.setOnClickListener(v -> {
            showLogoutConfirmation();
        });
    }

    private void showLogoutConfirmation() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Выход из аккаунта")
                .setMessage("Вы уверены, что хотите выйти? Все данные будут сохранены.")
                .setPositiveButton("Выйти", (dialog, which) -> {
                    logout();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void logout() {
        // ВЫХОДИМ ИЗ АККАУНТА
        prefsManager.logout();
        Toast.makeText(this, "Вы вышли из аккаунта", Toast.LENGTH_SHORT).show();

        // Переходим на экран авторизации и очищаем весь стек
        Intent intent = new Intent(this, AuthActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish(); // Закрываем ProfileActivity
    }

    private String getFitnessLevelDisplayName(String level) {
        if (level == null) return "Не указан";
        switch (level) {
            case "beginner": return "Начинающий";
            case "intermediate": return "Средний";
            case "advanced": return "Продвинутый";
            default: return level;
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}