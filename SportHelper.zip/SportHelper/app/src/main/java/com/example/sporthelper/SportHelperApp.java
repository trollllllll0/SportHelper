package com.example.sporthelper;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import com.example.sporthelper.activity.AuthActivity;
import com.example.sporthelper.activity.MainActivity;
import com.example.sporthelper.manager.SharedPreferencesManager;

public class SportHelperApp extends Application {
    private static SportHelperApp instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Проверяем авторизацию при запуске приложения
        checkAuthentication();
    }

    private void checkAuthentication() {
        SharedPreferencesManager prefsManager = SharedPreferencesManager.getInstance(this);

        if (!prefsManager.isLoggedIn()) {
            Log.d("SportHelperApp", "Пользователь не авторизован, запуск AuthActivity");
            // Если не авторизован, можно запустить AuthActivity
            // Но обычно это делается в лаунчер активности
        } else {
            Log.d("SportHelperApp", "Пользователь авторизован, ID: " + prefsManager.getUserId());
        }
    }

    public static SportHelperApp getInstance() {
        return instance;
    }
}
