package com.example.sporthelper.activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import com.example.sporthelper.R;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.viewmodel.AuthViewModel;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AuthActivity extends AppCompatActivity {
    private AuthViewModel authViewModel;
    private boolean isSignUpMode = false;

    // View variables для обеих форм
    private LinearLayout signInForm, signUpForm;
    private TextView signInTabButton, signUpTabButton;

    // Поля входа
    private EditText emailEditText, passwordEditText;
    private Button signInButton;

    // Поля регистрации
    private EditText signUpFullNameEditText, signUpUsernameEditText, signUpEmailEditText, signUpPasswordEditText;
    private RadioGroup genderRadioGroup;
    private Button birthDateButton, signUpButton;
    private TextView selectedDateText, weightValueText, heightValueText;
    private SeekBar weightSeekBar, heightSeekBar;
    private Spinner fitnessLevelSpinner;

    private ProgressBar progressBar;

    // Дата рождения
    private Calendar birthDateCalendar;
    private SimpleDateFormat dateFormatter;

    // Разрешенные почтовые сервисы
    private final List<String> allowedEmailDomains = Arrays.asList(
            "gmail.com", "yandex.ru", "mail.ru", "rambler.ru",
            "outlook.com", "hotmail.com", "yahoo.com", "icloud.com",
            "protonmail.com", "aol.com"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Log.d("AuthActivity", "=== НАЧАЛО onCreate ===");
            setContentView(R.layout.activity_auth);
            Log.d("AuthActivity", "setContentView выполнен");

            initViews();
            Log.d("AuthActivity", "initViews выполнен");

            initViewModel();
            Log.d("AuthActivity", "initViewModel выполнен");

            setupUI();
            Log.d("AuthActivity", "setupUI выполнен");

            updateUI();
            Log.d("AuthActivity", "updateUI выполнен");

            Log.d("AuthActivity", "=== УСПЕШНОЕ ЗАВЕРШЕНИЕ onCreate ===");

        } catch (Exception e) {
            Log.e("AuthActivity", "КРИТИЧЕСКАЯ ОШИБКА в onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Критическая ошибка при запуске", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initViews() {
        try {
            Log.d("AuthActivity", "Начало initViews");

            // Контейнеры форм
            signInForm = findViewById(R.id.signInForm);
            signUpForm = findViewById(R.id.signUpForm);

            // Кнопки переключения
            signInTabButton = findViewById(R.id.signInTabButton);
            signUpTabButton = findViewById(R.id.signUpTabButton);

            // Поля входа
            emailEditText = findViewById(R.id.emailEditText);
            passwordEditText = findViewById(R.id.passwordEditText);
            signInButton = findViewById(R.id.signInButton);

            // Поля регистрации
            signUpFullNameEditText = findViewById(R.id.signUpFullNameEditText);
            signUpUsernameEditText = findViewById(R.id.signUpUsernameEditText);
            signUpEmailEditText = findViewById(R.id.signUpEmailEditText);
            signUpPasswordEditText = findViewById(R.id.signUpPasswordEditText);
            genderRadioGroup = findViewById(R.id.genderRadioGroup);
            birthDateButton = findViewById(R.id.birthDateButton);
            signUpButton = findViewById(R.id.signUpButton);
            selectedDateText = findViewById(R.id.selectedDateText);
            weightValueText = findViewById(R.id.weightValueText);
            heightValueText = findViewById(R.id.heightValueText);
            weightSeekBar = findViewById(R.id.weightSeekBar);
            heightSeekBar = findViewById(R.id.heightSeekBar);
            fitnessLevelSpinner = findViewById(R.id.fitnessLevelSpinner);

            progressBar = findViewById(R.id.progressBar);

            // Инициализация календаря и формата даты
            birthDateCalendar = Calendar.getInstance();
            dateFormatter = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());

            Log.d("AuthActivity", "Все View успешно инициализированы");

        } catch (Exception e) {
            Log.e("AuthActivity", "Ошибка в initViews: " + e.getMessage(), e);
            throw new RuntimeException("Ошибка инициализации View: " + e.getMessage(), e);
        }
    }

    private void initViewModel() {
        authViewModel = new ViewModelProvider(this).get(AuthViewModel.class);
    }

    private void setupUI() {
        // Настройка переключения между формами
        signInTabButton.setOnClickListener(v -> switchToSignIn());
        signUpTabButton.setOnClickListener(v -> switchToSignUp());

        // Обработчики для формы входа
        signInButton.setOnClickListener(v -> attemptSignIn());

        // Обработчики для формы регистрации
        signUpButton.setOnClickListener(v -> attemptSignUp());

        // Выбор даты рождения
        birthDateButton.setOnClickListener(v -> showDatePickerDialog());

        // Настройка SeekBar для веса (40-120 кг)
        weightSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int weight = progress + 40; // 40-120 кг
                weightValueText.setText(weight + " кг");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Настройка SeekBar для роста (140-210 см)
        heightSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int height = progress + 140; // 140-210 см
                heightValueText.setText(height + " см");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Настройка Spinner для уровня подготовки
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.fitness_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fitnessLevelSpinner.setAdapter(adapter);

        // Валидация email при вводе
        setupEmailValidation(signUpEmailEditText);
        setupEmailValidation(emailEditText);

        setupObservers();

        // Устанавливаем начальные значения
        weightSeekBar.setProgress(30); // 70 кг
        heightSeekBar.setProgress(30); // 170 см

        // Устанавливаем уровень подготовки по умолчанию
        fitnessLevelSpinner.setSelection(0); // Начинающий

        // Устанавливаем мужской пол по умолчанию
        genderRadioGroup.check(R.id.genderMale);
    }

    private void switchToSignIn() {
        isSignUpMode = false;
        updateUI();
    }

    private void switchToSignUp() {
        isSignUpMode = true;
        updateUI();
    }

    private void updateUI() {
        if (isSignUpMode) {
            // Показываем форму регистрации
            signInForm.setVisibility(View.GONE);
            signUpForm.setVisibility(View.VISIBLE);

            // Обновляем кнопки табов
            signInTabButton.setSelected(false);
            signUpTabButton.setSelected(true);

            // Обновляем внешний вид кнопок
            updateTabAppearance();
        } else {
            // Показываем форму входа
            signInForm.setVisibility(View.VISIBLE);
            signUpForm.setVisibility(View.GONE);

            // Обновляем кнопки табов
            signInTabButton.setSelected(true);
            signUpTabButton.setSelected(false);

            // Обновляем внешний вид кнопок
            updateTabAppearance();
        }
    }

    private void updateTabAppearance() {
        // Принудительно обновляем внешний вид кнопок
        signInTabButton.post(() -> {
            signInTabButton.setSelected(signInTabButton.isSelected());
            signUpTabButton.setSelected(signUpTabButton.isSelected());
        });
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    birthDateCalendar.set(Calendar.YEAR, year);
                    birthDateCalendar.set(Calendar.MONTH, month);
                    birthDateCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    String selectedDate = dateFormatter.format(birthDateCalendar.getTime());
                    selectedDateText.setText(selectedDate);
                    selectedDateText.setTextColor(ContextCompat.getColor(this, R.color.sport_primary));
                },
                birthDateCalendar.get(Calendar.YEAR),
                birthDateCalendar.get(Calendar.MONTH),
                birthDateCalendar.get(Calendar.DAY_OF_MONTH)
        );

        // Устанавливаем максимальную дату (сегодня)
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void setupEmailValidation(EditText emailEditText) {
        emailEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                validateEmailFormat(emailEditText.getText().toString().trim());
            }
        });

        emailEditText.setOnKeyListener((v, keyCode, event) -> {
            new Handler().postDelayed(() -> {
                String currentText = emailEditText.getText().toString();
                if (!currentText.equals(currentText.toLowerCase())) {
                    emailEditText.setError("Email должен быть в нижнем регистре");
                } else {
                    emailEditText.setError(null);
                }
            }, 100);
            return false;
        });
    }

    private void attemptSignIn() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        Log.d("AuthActivity", "Попытка входа:");
        Log.d("AuthActivity", "Email: " + email);
        Log.d("AuthActivity", "Password length: " + password.length());

        if (validateSignInInput(email, password)) {
            authViewModel.signIn(email, password);
        }
    }

    private void attemptSignUp() {
        // Получаем данные из формы регистрации
        String fullName = signUpFullNameEditText.getText().toString().trim();
        String username = signUpUsernameEditText.getText().toString().trim();
        String email = signUpEmailEditText.getText().toString().trim();
        String password = signUpPasswordEditText.getText().toString().trim();

        // Пол
        String gender = getSelectedGender();

        // Дата рождения
        String dateOfBirth = null;
        if (birthDateCalendar != null && !selectedDateText.getText().toString().equals("Дата не выбрана")) {
            SimpleDateFormat dbFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            dateOfBirth = dbFormat.format(birthDateCalendar.getTime());
        }

        // Вес и рост
        double weight = weightSeekBar.getProgress() + 40.0;
        double height = heightSeekBar.getProgress() + 140.0;

        // Уровень подготовки
        String fitnessLevelDisplay = fitnessLevelSpinner.getSelectedItem().toString();
        String fitnessLevelDb = convertFitnessLevelToDb(fitnessLevelDisplay);

        Log.d("AuthActivity", "Попытка регистрации:");
        Log.d("AuthActivity", "FullName: " + fullName);
        Log.d("AuthActivity", "Username: " + username);
        Log.d("AuthActivity", "Email: " + email);
        Log.d("AuthActivity", "Password length: " + password.length());
        Log.d("AuthActivity", "Gender: " + gender);
        Log.d("AuthActivity", "DateOfBirth: " + dateOfBirth);
        Log.d("AuthActivity", "Weight: " + weight);
        Log.d("AuthActivity", "Height: " + height);
        Log.d("AuthActivity", "FitnessLevel: " + fitnessLevelDb);

        if (validateSignUpInput(fullName, username, email, password, gender, dateOfBirth)) {
            // ВЫЗЫВАЕМ С ПРАВИЛЬНЫМ ПОРЯДКОМ ПАРАМЕТРОВ
            authViewModel.signUp(email, password, username, fullName, gender, dateOfBirth, weight, height, fitnessLevelDb);
        }
    }

    private String getSelectedGender() {
        int selectedId = genderRadioGroup.getCheckedRadioButtonId();

        if (selectedId == R.id.genderMale) {
            return "male";
        } else if (selectedId == R.id.genderFemale) {
            return "female";
        }
        return "male"; // По умолчанию мужской
    }

    private String convertFitnessLevelToDb(String displayLevel) {
        switch (displayLevel) {
            case "Начинающий": return "beginner";
            case "Средний": return "intermediate";
            case "Продвинутый": return "advanced";
            default: return "beginner";
        }
    }

    private boolean validateSignInInput(String email, String password) {
        if (!validateEmailFormat(email)) {
            return false;
        }
        if (password.isEmpty() || password.length() < 6) {
            showError("Пароль должен содержать минимум 6 символов");
            return false;
        }
        return true;
    }

    private boolean validateSignUpInput(String fullName, String username, String email, String password,
                                        String gender, String dateOfBirth) {
        if (fullName.isEmpty()) {
            showError("Введите полное имя");
            return false;
        }
        if (username.isEmpty()) {
            showError("Введите имя пользователя");
            return false;
        }
        if (username.length() < 3) {
            showError("Имя пользователя должно содержать минимум 3 символа");
            return false;
        }
        if (username.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
            showError("Имя пользователя не должно содержать специальных символов");
            return false;
        }
        if (!validateEmailFormat(email)) {
            return false;
        }
        if (password.isEmpty() || password.length() < 6) {
            showError("Пароль должен содержать минимум 6 символов");
            return false;
        }
        if (dateOfBirth == null) {
            showError("Выберите дату рождения");
            return false;
        }
        return true;
    }

    private boolean validateEmailFormat(String email) {
        if (email.isEmpty()) {
            showError("Введите email");
            return false;
        }

        if (!email.equals(email.toLowerCase())) {
            showError("Email должен быть в нижнем регистре (только маленькие буквы)");
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Введите корректный email адрес");
            return false;
        }

        String emailDomain = email.substring(email.indexOf('@') + 1);

        boolean isAllowed = false;
        for (String allowedDomain : allowedEmailDomains) {
            if (emailDomain.equals(allowedDomain)) {
                isAllowed = true;
                break;
            }
        }

        if (!isAllowed) {
            showError("Разрешены только базовые почтовые сервисы: Gmail, Яндекс, Mail и др.");
            return false;
        }

        return true;
    }

    private void setupObservers() {
        authViewModel.getAuthResult().observe(this, resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case LOADING:
                    showProgress(true);
                    new Handler().postDelayed(() -> {
                        if (progressBar.getVisibility() == View.VISIBLE) {
                            showProgress(false);
                            showError("Превышено время ожидания. Проверьте интернет-соединение.");
                        }
                    }, 10000);
                    break;
                case SUCCESS:
                    showProgress(false);
                    handleAuthSuccess(resource.data);
                    break;
                case ERROR:
                    showProgress(false);
                    showError(resource.message);
                    Log.e("AuthActivity", "Auth error: " + resource.message);
                    break;
            }
        });
    }

    private void handleAuthSuccess(Profile profile) {
        try {
            if (profile != null) {
                String message = isSignUpMode ? "Регистрация выполнена!" : "Вход выполнен!";
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

                Log.d("AuthActivity", "=== УСПЕШНАЯ АУТЕНТИФИКАЦИЯ ===");
                Log.d("AuthActivity", "ID: " + profile.getId());
                Log.d("AuthActivity", "Username: " + profile.getUsername());
                Log.d("AuthActivity", "FullName: " + profile.getFullName());
                Log.d("AuthActivity", "FitnessLevel: " + profile.getFitnessLevel());
                Log.d("AuthActivity", "Weight: " + profile.getWeight());
                Log.d("AuthActivity", "Height: " + profile.getHeight());

                if (profile.getId() == null) {
                    Log.e("AuthActivity", "ОШИБКА: ID пользователя null!");
                    showError("Ошибка: не получен ID пользователя");
                    return;
                }

                if (profile.getUsername() == null) {
                    Log.w("AuthActivity", "Username null, устанавливаем 'User'");
                    profile.setUsername("User");
                }

                // СОХРАНЯЕМ ПРОФИЛЬ В SharedPreferences
                SharedPreferencesManager prefsManager = SharedPreferencesManager.getInstance(this);
                prefsManager.setLoggedIn(true);
                prefsManager.saveUserProfile(profile);

                Log.d("AuthActivity", "Профиль сохранен в SharedPreferences");

                // Переход на MainActivity
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("profile", profile);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                Log.d("AuthActivity", "Запуск MainActivity...");
                startActivity(intent);
                // Не вызываем finish() - система сама закроет AuthActivity

            } else {
                Log.e("AuthActivity", "ОШИБКА: профиль null!");
                showError("Ошибка: профиль не получен");
            }
        } catch (Exception e) {
            Log.e("AuthActivity", "КРИТИЧЕСКАЯ ОШИБКА в handleAuthSuccess: " + e.getMessage(), e);
            showError("Критическая ошибка: " + e.getMessage());
        }
    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        signInButton.setEnabled(!show);
        signUpButton.setEnabled(!show);
        signInTabButton.setEnabled(!show);
        signUpTabButton.setEnabled(!show);

        if (show) {
            signInButton.setText("Вход...");
            signUpButton.setText("Регистрация...");
        } else {
            signInButton.setText("ВОЙТИ");
            signUpButton.setText("ЗАРЕГИСТРИРОВАТЬСЯ");
        }
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        Log.e("AuthActivity", "Error: " + message);
    }
}
