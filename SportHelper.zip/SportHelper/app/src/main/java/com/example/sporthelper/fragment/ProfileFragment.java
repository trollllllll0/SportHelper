package com.example.sporthelper.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.sporthelper.databinding.FragmentProfileBinding;
import com.example.sporthelper.model.Profile;

public class ProfileFragment extends Fragment {
    private FragmentProfileBinding binding;
    private Profile currentUser;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // ВРЕМЕННОЕ РЕШЕНИЕ
        View view = inflater.inflate(com.example.sporthelper.R.layout.fragment_profile, container, false);
        binding = FragmentProfileBinding.bind(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupUserData();
        setupUI();
    }

    private void setupUserData() {
        // В реальном приложении получаем из ViewModel или SharedPreferences
        currentUser = new Profile();
        currentUser.setUsername("Иван Иванов");
        currentUser.setEmail("ivan@example.com");
        currentUser.setFitnessLevel("intermediate");
        currentUser.setWeight(75.5);
        currentUser.setHeight(180.0);

        updateUI();
    }

    private void updateUI() {
        binding.usernameText.setText(currentUser.getUsername());
        binding.emailText.setText(currentUser.getEmail());
        binding.fitnessLevelText.setText(getFitnessLevelDisplayName(currentUser.getFitnessLevel()));

        if (currentUser.getWeight() != null && currentUser.getHeight() != null) {
            String stats = currentUser.getWeight() + " кг / " + currentUser.getHeight() + " см";
            binding.statsText.setText(stats);
        }
    }

    private String getFitnessLevelDisplayName(String level) {
        if (level == null) return "Не указан";

        switch (level) {
            case "beginner": return "Начинающий";
            case "intermediate": return "Средний";
            case "advanced": return "Продвинутый";
            default: return level;
        }
    }

    private void setupUI() {
        binding.editProfileButton.setOnClickListener(v -> editProfile());
        binding.settingsButton.setOnClickListener(v -> openSettings());
        binding.logoutButton.setOnClickListener(v -> logout());
    }

    private void editProfile() {
        Toast.makeText(getContext(), "Редактирование профиля", Toast.LENGTH_SHORT).show();
    }

    private void openSettings() {
        Toast.makeText(getContext(), "Настройки", Toast.LENGTH_SHORT).show();
    }

    private void logout() {
        Toast.makeText(getContext(), "Выход из аккаунта", Toast.LENGTH_SHORT).show();
        // В реальном приложении: очистка данных и переход на AuthActivity
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
