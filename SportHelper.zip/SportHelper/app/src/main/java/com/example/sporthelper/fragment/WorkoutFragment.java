package com.example.sporthelper.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.sporthelper.databinding.FragmentWorkoutBinding;
import com.example.sporthelper.model.Workout;
import com.example.sporthelper.viewmodel.WorkoutViewModel;
import com.example.sporthelper.adapter.WorkoutAdapter;
import java.util.List;

public class WorkoutFragment extends Fragment {
    private FragmentWorkoutBinding binding;
    private WorkoutViewModel workoutViewModel;
    private WorkoutAdapter workoutAdapter;
    private Long currentUserId = 1L;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // ВРЕМЕННОЕ РЕШЕНИЕ
        View view = inflater.inflate(com.example.sporthelper.R.layout.fragment_workout, container, false);
        binding = FragmentWorkoutBinding.bind(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViewModels();
        setupRecyclerView();
        setupUI();
        loadWorkouts();
    }

    private void initViewModels() {
        workoutViewModel = new ViewModelProvider(requireActivity()).get(WorkoutViewModel.class);
    }

    private void setupRecyclerView() {
        workoutAdapter = new WorkoutAdapter(null, new WorkoutAdapter.OnWorkoutClickListener() {
            @Override
            public void onWorkoutClick(Workout workout) {
                showWorkoutDetails(workout);
            }

            @Override
            public void onWorkoutLongClick(Workout workout) {
                showWorkoutActions(workout);
            }
        });

        binding.workoutsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.workoutsRecyclerView.setAdapter(workoutAdapter);
    }

    private void setupUI() {
        binding.refreshButton.setOnClickListener(v -> {
            loadWorkouts();
            Toast.makeText(getContext(), "Обновление...", Toast.LENGTH_SHORT).show();
        });

        binding.addWorkoutButton.setOnClickListener(v -> showAddWorkoutDialog());
    }

    private void loadWorkouts() {
        workoutViewModel.loadWorkouts(currentUserId);
        workoutViewModel.getWorkouts().observe(getViewLifecycleOwner(), resource -> {
            if (resource != null && resource.data != null) {
                List<Workout> workouts = resource.data;
                workoutAdapter.updateWorkouts(workouts);
                showEmptyState(workouts.isEmpty());
            }
        });
    }

    private void showWorkoutDetails(Workout workout) {
        Toast.makeText(getContext(), workout.getWorkoutName(), Toast.LENGTH_SHORT).show();
    }

    private void showWorkoutActions(Workout workout) {
        Toast.makeText(getContext(), "Действия: " + workout.getWorkoutName(), Toast.LENGTH_SHORT).show();
    }

    private void showAddWorkoutDialog() {
        Toast.makeText(getContext(), "Добавить тренировку", Toast.LENGTH_SHORT).show();
    }

    private void showEmptyState(boolean show) {
        binding.emptyState.setVisibility(show ? View.VISIBLE : View.GONE);
        binding.workoutsRecyclerView.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
