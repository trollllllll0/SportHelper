package com.example.sporthelper.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.NutritionLog;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.repository.NutritionRepository;

import java.util.List;

public class NutritionViewModel extends AndroidViewModel {
    private NutritionRepository nutritionRepository;
    private MutableLiveData<Resource<List<NutritionLog>>> nutritionLogs = new MutableLiveData<>();
    private MutableLiveData<Resource<String>> photoAnalysisResult = new MutableLiveData<>();

    public NutritionViewModel(@NonNull Application application) {
        super(application);
        this.nutritionRepository = new NutritionRepository(application.getApplicationContext());
    }

    public void loadNutritionLogs(Long userId, String date) {
        nutritionRepository.getNutritionLogs(userId, date).observeForever(result -> {
            nutritionLogs.postValue(result);
        });
    }

    public void analyzeFoodPhoto(byte[] imageData) {
        nutritionRepository.analyzeFoodPhoto(imageData).observeForever(result -> {
            photoAnalysisResult.postValue(result);
        });
    }

    public LiveData<Resource<List<NutritionLog>>> getNutritionLogs() { return nutritionLogs; }
    public LiveData<Resource<String>> getPhotoAnalysisResult() { return photoAnalysisResult; }
}
