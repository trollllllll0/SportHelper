package com.example.sporthelper.model;
public class NutritionLog {
    private Long id;
    private Long userId;
    private String logDate;
    private String mealType;
    private String foodName;
    private Integer calories;
    private Double protein;
    private Double carbs;
    private Double fat;

    public NutritionLog() {}

    public NutritionLog(Long id, Long userId, String logDate, String mealType,
                        String foodName, Integer calories, Double protein, Double carbs, Double fat) {
        this.id = id;
        this.userId = userId;
        this.logDate = logDate;
        this.mealType = mealType;
        this.foodName = foodName;
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.fat = fat;
    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getLogDate() { return logDate; }
    public void setLogDate(String logDate) { this.logDate = logDate; }

    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }

    public String getFoodName() { return foodName; }
    public void setFoodName(String foodName) { this.foodName = foodName; }

    public Integer getCalories() { return calories; }
    public void setCalories(Integer calories) { this.calories = calories; }

    public Double getProtein() { return protein; }
    public void setProtein(Double protein) { this.protein = protein; }

    public Double getCarbs() { return carbs; }
    public void setCarbs(Double carbs) { this.carbs = carbs; }

    public Double getFat() { return fat; }
    public void setFat(Double fat) { this.fat = fat; }
}
