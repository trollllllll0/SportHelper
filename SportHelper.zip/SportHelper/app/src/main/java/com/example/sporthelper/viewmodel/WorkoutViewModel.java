package com.example.sporthelper.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Resource;
import com.example.sporthelper.model.Workout;
import com.example.sporthelper.repository.WorkoutRepository;

import java.util.List;

public class WorkoutViewModel extends AndroidViewModel {
    private WorkoutRepository workoutRepository;
    private MutableLiveData<Resource<List<Workout>>> workouts = new MutableLiveData<>();

    public WorkoutViewModel(@NonNull Application application) {
        super(application);
        this.workoutRepository = new WorkoutRepository(application.getApplicationContext());
    }

    public void loadWorkouts(Long userId) {
        workoutRepository.getWorkoutsByUser(userId).observeForever(result -> {
            workouts.postValue(result);
        });
    }

    public LiveData<Resource<List<Workout>>> getWorkouts() {
        return workouts;
    }
}
