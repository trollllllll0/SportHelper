package com.example.sporthelper.activity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

import com.example.sporthelper.R;
import com.example.sporthelper.manager.SharedPreferencesManager;

public class SettingsActivity extends AppCompatActivity {
    private SharedPreferencesManager prefsManager;
    private SharedPreferences settingsPrefs;

    private SwitchCompat notificationsSwitch, darkThemeSwitch, syncSwitch;
    private Button aboutButton, privacyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefsManager = SharedPreferencesManager.getInstance(this);
        settingsPrefs = prefsManager.getSharedPreferences();

        initViews();
        setupUI();
    }

    private void initViews() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Настройки");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        notificationsSwitch = findViewById(R.id.notificationsSwitch);
        darkThemeSwitch = findViewById(R.id.darkThemeSwitch);
        syncSwitch = findViewById(R.id.syncSwitch);
        aboutButton = findViewById(R.id.aboutButton);
        privacyButton = findViewById(R.id.privacyButton);
    }

    private void setupUI() {
        // Загружаем сохраненные настройки
        loadSettings();

        notificationsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            saveSetting("notifications", isChecked);
            Toast.makeText(this, "Уведомления " + (isChecked ? "включены" : "выключены"), Toast.LENGTH_SHORT).show();
        });

        darkThemeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            saveSetting("dark_theme", isChecked);
            Toast.makeText(this, "Темная тема " + (isChecked ? "включена" : "выключена"), Toast.LENGTH_SHORT).show();
        });

        syncSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            saveSetting("auto_sync", isChecked);
            Toast.makeText(this, "Синхронизация " + (isChecked ? "включена" : "выключена"), Toast.LENGTH_SHORT).show();
        });

        // Добавляем обработчики для кнопок
        if (aboutButton != null) {
            aboutButton.setOnClickListener(v -> {
                Toast.makeText(this, "О приложении", Toast.LENGTH_SHORT).show();
            });
        }

        if (privacyButton != null) {
            privacyButton.setOnClickListener(v -> {
                Toast.makeText(this, "Политика конфиденциальности", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void loadSettings() {
        // Загружаем настройки из SharedPreferences
        notificationsSwitch.setChecked(settingsPrefs.getBoolean("notifications", true));
        darkThemeSwitch.setChecked(settingsPrefs.getBoolean("dark_theme", false));
        syncSwitch.setChecked(settingsPrefs.getBoolean("auto_sync", true));
    }

    private void saveSetting(String key, boolean value) {
        // Сохраняем настройку в SharedPreferences
        settingsPrefs.edit().putBoolean(key, value).apply();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
