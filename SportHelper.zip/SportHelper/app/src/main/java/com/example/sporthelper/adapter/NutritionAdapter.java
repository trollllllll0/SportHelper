package com.example.sporthelper.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.model.NutritionLog;

import java.util.List;

public class NutritionAdapter extends RecyclerView.Adapter<NutritionAdapter.NutritionViewHolder> {
    private List<NutritionLog> nutritionLogs;

    public NutritionAdapter(List<NutritionLog> nutritionLogs) {
        this.nutritionLogs = nutritionLogs;
    }

    @NonNull
    @Override
    public NutritionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_nutrition, parent, false);
        return new NutritionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NutritionViewHolder holder, int position) {
        NutritionLog log = nutritionLogs.get(position);
        holder.bind(log);
    }

    @Override
    public int getItemCount() {
        return nutritionLogs != null ? nutritionLogs.size() : 0;
    }

    public void updateNutritionLogs(List<NutritionLog> newLogs) {
        this.nutritionLogs = newLogs;
        notifyDataSetChanged();
    }

    static class NutritionViewHolder extends RecyclerView.ViewHolder {
        private TextView mealTypeTextView;
        private TextView foodNameTextView;
        private TextView caloriesTextView;
        private TextView nutrientsTextView;

        public NutritionViewHolder(View itemView) {
            super(itemView);
            mealTypeTextView = itemView.findViewById(R.id.mealType);
            foodNameTextView = itemView.findViewById(R.id.foodName);
            caloriesTextView = itemView.findViewById(R.id.calories);
            nutrientsTextView = itemView.findViewById(R.id.nutrients);
        }

        public void bind(NutritionLog log) {
            mealTypeTextView.setText(getMealTypeDisplayName(log.getMealType()));
            foodNameTextView.setText(log.getFoodName());
            caloriesTextView.setText(log.getCalories() + " ккал");

            String nutrients = String.format("Б:%.1fг, Ж:%.1fг, У:%.1fг",
                    log.getProtein() != null ? log.getProtein() : 0,
                    log.getFat() != null ? log.getFat() : 0,
                    log.getCarbs() != null ? log.getCarbs() : 0);
            nutrientsTextView.setText(nutrients);
        }

        private String getMealTypeDisplayName(String mealType) {
            if (mealType == null) return "Прием пищи";

            switch (mealType) {
                case "breakfast": return "🍳 Завтрак";
                case "lunch": return "🍲 Обед";
                case "dinner": return "🍽️ Ужин";
                case "snack": return "🍎 Перекус";
                default: return mealType;
            }
        }
    }
}
