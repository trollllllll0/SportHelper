package com.example.sporthelper.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.adapter.WorkoutAdapter;
import com.example.sporthelper.manager.SharedPreferencesManager;
import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.model.Workout;
import com.example.sporthelper.viewmodel.WorkoutViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private WorkoutViewModel workoutViewModel;
    private WorkoutAdapter workoutAdapter;
    private Profile currentUser;
    private SharedPreferencesManager prefsManager;

    // View variables
    private RecyclerView workoutsRecyclerView;
    private ImageButton refreshButton;
    private ExtendedFloatingActionButton addWorkoutButton;
    private MaterialToolbar toolbar;
    private BottomNavigationView bottomNavigation;

    // New stats views
    private TextView totalWorkoutsText, totalCaloriesText, totalMinutesText, welcomeText;
    private TextView noWorkoutsText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d("MainActivity", "=== НАЧАЛО onCreate ===");

        try {
            setContentView(R.layout.activity_main);
            Log.d("MainActivity", "setContentView выполнен");

            // Инициализируем менеджер SharedPreferences
            prefsManager = SharedPreferencesManager.getInstance(this);

            // ПЕРВОЕ - получаем данные пользователя
            initUserData();
            Log.d("MainActivity", "initUserData выполнен");

            // Если пользователь не авторизован - выходим
            if (currentUser == null) {
                return;
            }

            // Настройка обработчика кнопки "Назад"
            setupBackPressedHandler();

            // ВТОРОЕ - инициализируем View
            initViews();
            Log.d("MainActivity", "initViews выполнен");

            // ТРЕТЬЕ - настройка остального
            initViewModels();
            Log.d("MainActivity", "initViewModels выполнен");

            setupRecyclerView();
            Log.d("MainActivity", "setupRecyclerView выполнен");

            setupUI();
            Log.d("MainActivity", "setupUI выполнен");

            loadWorkouts();
            Log.d("MainActivity", "loadWorkouts выполнен");

            Log.d("MainActivity", "=== УСПЕШНОЕ ЗАВЕРШЕНИЕ onCreate ===");

        } catch (Exception e) {
            Log.e("MainActivity", "КРИТИЧЕСКАЯ ОШИБКА в onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Критическая ошибка при запуске: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void initUserData() {
        Log.d("MainActivity", "Начало initUserData");

        try {
            // Пытаемся получить профиль из Intent (при первом входе)
            Intent intent = getIntent();
            if (intent != null && intent.hasExtra("profile")) {
                currentUser = (Profile) intent.getSerializableExtra("profile");
                if (currentUser != null) {
                    // Сохраняем профиль при первом входе
                    prefsManager.saveUserProfile(currentUser);
                    prefsManager.setLoggedIn(true);
                    Log.d("MainActivity", "Профиль получен из Intent и сохранен");
                }
            }

            // Если профиль не получен из Intent, загружаем из SharedPreferences
            if (currentUser == null) {
                currentUser = prefsManager.getUserProfile();
                if (currentUser != null) {
                    Log.d("MainActivity", "Профиль загружен из SharedPreferences");
                }
            }

            // ЕСЛИ ПРОФИЛЬ НЕ НАЙДЕН - ПЕРЕХОДИМ НА AUTH И ЗАКРЫВАЕМ MainActivity
            if (currentUser == null) {
                Log.e("MainActivity", "Профиль не найден! Переход на AuthActivity");
                Toast.makeText(this, "Необходима авторизация", Toast.LENGTH_SHORT).show();

                Intent authIntent = new Intent(MainActivity.this, AuthActivity.class);
                authIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(authIntent);
                finish();
                return;
            }

            // Проверяем обязательные поля
            if (currentUser.getId() == null) {
                Log.e("MainActivity", "ID пользователя null!");
                currentUser.setId(prefsManager.getUserId());
            }

            if (currentUser.getUsername() == null) {
                Log.w("MainActivity", "Username null, устанавливаем 'User'");
                currentUser.setUsername("User");
            }

            if (currentUser.getEmail() == null) {
                Log.w("MainActivity", "Email null, устанавливаем 'user@example.com'");
                currentUser.setEmail("user@example.com");
            }

            Log.d("MainActivity", "Пользователь успешно загружен:");
            Log.d("MainActivity", "ID: " + currentUser.getId());
            Log.d("MainActivity", "Username: " + currentUser.getUsername());
            Log.d("MainActivity", "Email: " + currentUser.getEmail());

        } catch (Exception e) {
            Log.e("MainActivity", "ОШИБКА в initUserData: " + e.getMessage(), e);
            Toast.makeText(this, "Ошибка загрузки профиля: " + e.getMessage(), Toast.LENGTH_LONG).show();

            // При ошибке переходим на экран авторизации
            Intent authIntent = new Intent(MainActivity.this, AuthActivity.class);
            authIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(authIntent);
            finish();
        }
    }

    private void initViews() {
        try {
            Log.d("MainActivity", "Начало initViews");

            workoutsRecyclerView = findViewById(R.id.workoutsRecyclerView);
            if (workoutsRecyclerView == null) throw new RuntimeException("workoutsRecyclerView не найден");

            refreshButton = findViewById(R.id.refreshButton);
            if (refreshButton == null) throw new RuntimeException("refreshButton не найден");

            addWorkoutButton = findViewById(R.id.addWorkoutButton);
            if (addWorkoutButton == null) throw new RuntimeException("addWorkoutButton не найден");

            toolbar = findViewById(R.id.toolbar);
            if (toolbar == null) throw new RuntimeException("toolbar не найден");

            bottomNavigation = findViewById(R.id.bottomNavigation);
            if (bottomNavigation == null) throw new RuntimeException("bottomNavigation не найден");

            // Новые View для статистики
            totalWorkoutsText = findViewById(R.id.totalWorkoutsText);
            totalCaloriesText = findViewById(R.id.totalCaloriesText);
            totalMinutesText = findViewById(R.id.totalMinutesText);
            welcomeText = findViewById(R.id.welcomeText);

            // Используем noWorkoutsText вместо emptyState
            noWorkoutsText = findViewById(R.id.noWorkoutsText);
            if (noWorkoutsText == null) {
                Log.w("MainActivity", "noWorkoutsText не найден");
            }

            Log.d("MainActivity", "Все View успешно инициализированы");

        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка в initViews: " + e.getMessage(), e);
            throw new RuntimeException("Ошибка инициализации View: " + e.getMessage(), e);
        }
    }

    private void initViewModels() {
        try {
            workoutViewModel = new ViewModelProvider(this).get(WorkoutViewModel.class);
            Log.d("MainActivity", "ViewModels инициализированы");
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка инициализации ViewModels: " + e.getMessage(), e);
            throw new RuntimeException("Ошибка инициализации ViewModels: " + e.getMessage(), e);
        }
    }

    private void setupRecyclerView() {
        try {
            workoutAdapter = new WorkoutAdapter(null, new WorkoutAdapter.OnWorkoutClickListener() {
                @Override
                public void onWorkoutClick(Workout workout) {
                    showWorkoutDetails(workout);
                }

                @Override
                public void onWorkoutLongClick(Workout workout) {
                    showWorkoutActionsDialog(workout);
                }
            });

            workoutsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            workoutsRecyclerView.setAdapter(workoutAdapter);

            Log.d("MainActivity", "RecyclerView настроен");
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка настройки RecyclerView: " + e.getMessage(), e);
            throw new RuntimeException("Ошибка настройки RecyclerView: " + e.getMessage(), e);
        }
    }

    private void setupUI() {
        try {
            // Устанавливаем приветствие
            if (welcomeText != null) {
                String welcomeMessage = "Готов к тренировке, " + currentUser.getUsername() + "?";
                welcomeText.setText(welcomeMessage);
            }

            // Устанавливаем заголовок в Toolbar
            if (toolbar != null) {
                toolbar.setTitle("Добро пожаловать, " + currentUser.getUsername() + "!");
                setSupportActionBar(toolbar);
            }

            refreshButton.setOnClickListener(v -> {
                loadWorkouts();
                Toast.makeText(MainActivity.this, "Обновление...", Toast.LENGTH_SHORT).show();
            });

            addWorkoutButton.setOnClickListener(v -> showAddWorkoutDialog());

            bottomNavigation.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_workouts) {
                    // Уже на главной странице тренировок
                    return true;
                } else if (itemId == R.id.nav_nutrition) {
                    startActivity(new Intent(MainActivity.this, NutritionActivity.class));
                    return true;
                } else if (itemId == R.id.nav_chat) {
                    showComingSoonDialog("Чат с тренером");
                    return true;
                }
                return false;
            });

            Log.d("MainActivity", "UI настроен");
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка настройки UI: " + e.getMessage(), e);
            throw new RuntimeException("Ошибка настройки UI: " + e.getMessage(), e);
        }
    }

    private void loadWorkouts() {
        try {
            if (currentUser == null || currentUser.getId() == null) {
                Log.e("MainActivity", "Ошибка: пользователь или ID пользователя null");
                showError("Ошибка загрузки тренировок: пользователь не найден");
                return;
            }

            Log.d("MainActivity", "Загрузка тренировок для пользователя: " + currentUser.getId());

            workoutViewModel.loadWorkouts(currentUser.getId());
            workoutViewModel.getWorkouts().observe(this, resource -> {
                if (resource != null) {
                    Log.d("MainActivity", "Получены данные тренировок: " + resource.status);

                    switch (resource.status) {
                        case LOADING:
                            // Показываем прогресс, если нужно
                            Log.d("MainActivity", "Загрузка тренировок...");
                            break;
                        case SUCCESS:
                            List<Workout> workouts = resource.data;
                            Log.d("MainActivity", "Загружено тренировок: " + (workouts != null ? workouts.size() : 0));

                            if (workoutAdapter != null) {
                                workoutAdapter.updateWorkouts(workouts);
                            } else {
                                Log.e("MainActivity", "workoutAdapter is null");
                            }

                            // Обновляем видимость текста и RecyclerView
                            updateWorkoutVisibility(workouts);

                            // Обновляем статистику
                            updateWorkoutStats(workouts);
                            break;
                        case ERROR:
                            Log.e("MainActivity", "Ошибка загрузки тренировок: " + resource.message);
                            updateWorkoutVisibility(null);
                            showError("Не удалось загрузить тренировки: " + resource.message);
                            break;
                    }
                } else {
                    Log.e("MainActivity", "Resource is null");
                    showError("Ошибка загрузки тренировок");
                }
            });
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка загрузки тренировок: " + e.getMessage(), e);
            showError("Ошибка загрузки тренировок: " + e.getMessage());
        }
    }

    // Новый метод для обновления видимости элементов
    private void updateWorkoutVisibility(List<Workout> workouts) {
        try {
            if (workouts == null || workouts.isEmpty()) {
                // Показываем текст "нет тренировок" и скрываем RecyclerView
                if (noWorkoutsText != null) {
                    noWorkoutsText.setVisibility(View.VISIBLE);
                }
                if (workoutsRecyclerView != null) {
                    workoutsRecyclerView.setVisibility(View.GONE);
                }
            } else {
                // Показываем RecyclerView и скрываем текст "нет тренировок"
                if (noWorkoutsText != null) {
                    noWorkoutsText.setVisibility(View.GONE);
                }
                if (workoutsRecyclerView != null) {
                    workoutsRecyclerView.setVisibility(View.VISIBLE);
                }
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка обновления видимости: " + e.getMessage(), e);
        }
    }

    // Новый метод для обновления статистики
    private void updateWorkoutStats(List<Workout> workouts) {
        if (workouts == null || workouts.isEmpty()) {
            if (totalWorkoutsText != null) totalWorkoutsText.setText("0");
            if (totalCaloriesText != null) totalCaloriesText.setText("0");
            if (totalMinutesText != null) totalMinutesText.setText("0");
            return;
        }

        int totalWorkouts = workouts.size();
        int totalCalories = 0;
        int totalMinutes = 0;

        for (Workout workout : workouts) {
            if (workout.getCaloriesBurned() != null) {
                totalCalories += workout.getCaloriesBurned();
            }
            if (workout.getDurationMinutes() != null) {
                totalMinutes += workout.getDurationMinutes();
            }
        }

        if (totalWorkoutsText != null) totalWorkoutsText.setText(String.valueOf(totalWorkouts));
        if (totalCaloriesText != null) totalCaloriesText.setText(String.valueOf(totalCalories));
        if (totalMinutesText != null) totalMinutesText.setText(String.valueOf(totalMinutes));
    }

    private void showWorkoutDetails(Workout workout) {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(workout.getWorkoutName())
                    .setMessage("Дата: " + workout.getWorkoutDate() + "\n" +
                            "Длительность: " + workout.getDurationMinutes() + " мин\n" +
                            "Калории: " + workout.getCaloriesBurned() + " ккал\n\n" +
                            "Заметки: " + (workout.getNotes() != null ? workout.getNotes() : "нет заметок"))
                    .setPositiveButton("OK", null)
                    .show();
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка показа деталей тренировки: " + e.getMessage(), e);
        }
    }

    private void showWorkoutActionsDialog(Workout workout) {
        try {
            String[] actions = {"Редактировать", "Удалить", "Дублировать"};

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Действия с тренировкой")
                    .setItems(actions, (dialog, which) -> {
                        switch (which) {
                            case 0:
                                editWorkout(workout);
                                break;
                            case 1:
                                deleteWorkout(workout);
                                break;
                            case 2:
                                duplicateWorkout(workout);
                                break;
                        }
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка показа диалога действий: " + e.getMessage(), e);
        }
    }

    private void showAddWorkoutDialog() {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Новая тренировка")
                    .setMessage("Функция добавления тренировки в разработке")
                    .setPositiveButton("OK", null)
                    .show();
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка показа диалога добавления: " + e.getMessage(), e);
        }
    }

    private void editWorkout(Workout workout) {
        Toast.makeText(this, "Редактирование: " + workout.getWorkoutName(), Toast.LENGTH_SHORT).show();
    }

    private void deleteWorkout(Workout workout) {
        try {
            new AlertDialog.Builder(this)
                    .setTitle("Удаление тренировки")
                    .setMessage("Удалить тренировку \"" + workout.getWorkoutName() + "\"?")
                    .setPositiveButton("Удалить", (dialog, which) -> {
                        Toast.makeText(this, "Тренировка удалена", Toast.LENGTH_SHORT).show();
                        loadWorkouts();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка удаления тренировки: " + e.getMessage(), e);
        }
    }

    private void duplicateWorkout(Workout workout) {
        Toast.makeText(this, "Тренировка дублирована: " + workout.getWorkoutName(), Toast.LENGTH_SHORT).show();
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void showComingSoonDialog(String feature) {
        try {
            new AlertDialog.Builder(this)
                    .setTitle("Скоро будет!")
                    .setMessage("Функция \"" + feature + "\" находится в разработке")
                    .setPositiveButton("OK", null)
                    .show();
        } catch (Exception e) {
            Log.e("MainActivity", "Ошибка показа диалога: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_refresh) {
            loadWorkouts();
            Toast.makeText(this, "Обновление...", Toast.LENGTH_SHORT).show();
            return true;
        } else if (itemId == R.id.action_profile) {
            // Открываем экран профиля
            Intent intent = new Intent(this, ProfileActivity.class);
            intent.putExtra("profile", currentUser);
            startActivity(intent);
            return true;
        } else if (itemId == R.id.action_settings) {
            // Открываем экран настроек
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void setupBackPressedHandler() {
        // Обработка нажатия кнопки "Назад" - минимизируем приложение
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Минимизируем приложение вместо выхода
                minimizeApp();
            }
        });
    }

    private void minimizeApp() {
        // Создаем intent для перехода на домашний экран
        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(startMain);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("MainActivity", "onDestroy");
    }
}
