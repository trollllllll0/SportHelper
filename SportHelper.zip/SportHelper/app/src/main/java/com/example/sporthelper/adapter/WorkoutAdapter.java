package com.example.sporthelper.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.model.Workout;

import java.util.List;

public class WorkoutAdapter extends RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder> {
    private List<Workout> workouts;
    private OnWorkoutClickListener listener;

    public interface OnWorkoutClickListener {
        void onWorkoutClick(Workout workout);
        void onWorkoutLongClick(Workout workout);
    }

    public WorkoutAdapter(List<Workout> workouts, OnWorkoutClickListener listener) {
        this.workouts = workouts;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WorkoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_workout, parent, false);
        return new WorkoutViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkoutViewHolder holder, int position) {
        Workout workout = workouts.get(position);
        holder.bind(workout);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onWorkoutClick(workout);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onWorkoutLongClick(workout);
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return workouts != null ? workouts.size() : 0;
    }

    public void updateWorkouts(List<Workout> newWorkouts) {
        this.workouts = newWorkouts;
        notifyDataSetChanged();
    }

    static class WorkoutViewHolder extends RecyclerView.ViewHolder {
        private TextView nameTextView;
        private TextView dateTextView;
        private TextView durationTextView;
        private TextView caloriesTextView;

        public WorkoutViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.workoutName);
            dateTextView = itemView.findViewById(R.id.workoutDate);
            durationTextView = itemView.findViewById(R.id.workoutDuration);
            caloriesTextView = itemView.findViewById(R.id.workoutCalories);
        }

        public void bind(Workout workout) {
            nameTextView.setText(workout.getWorkoutName());
            dateTextView.setText(workout.getWorkoutDate());
            durationTextView.setText(workout.getDurationMinutes() + " мин");
            caloriesTextView.setText(workout.getCaloriesBurned() + " ккал");
        }
    }
}
