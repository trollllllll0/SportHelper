package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonNull;

import okhttp3.Request;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AuthRepository extends BaseRepository {
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Gson gson = new Gson();

    // Добавляем конструктор с Context
    public AuthRepository(Context context) {
        super(context); // Передаем контекст в базовый класс
    }

    // СИНХРОННЫЙ метод для регистрации - ИСПРАВЛЕННЫЙ
    public Resource<Profile> signUpSync(String email, String password, String username,
                                        String fullName, String gender, String dateOfBirth,
                                        double weight, double height, String fitnessLevel) {
        try {
            String normalizedEmail = email.toLowerCase();

            Log.d("AuthRepository", "=== НАЧАЛО РЕГИСТРАЦИИ ===");
            Log.d("AuthRepository", "Email: " + normalizedEmail);
            Log.d("AuthRepository", "Username: " + username);
            Log.d("AuthRepository", "FullName: " + fullName);
            Log.d("AuthRepository", "Password length: " + password.length());
            Log.d("AuthRepository", "Gender: " + gender);
            Log.d("AuthRepository", "Date of Birth: " + dateOfBirth);
            Log.d("AuthRepository", "Weight: " + weight);
            Log.d("AuthRepository", "Height: " + height);
            Log.d("AuthRepository", "Fitness Level: " + fitnessLevel);

            // СОЗДАЕМ JSON С ПРАВИЛЬНЫМИ ПОЛЯМИ
            JsonObject profileData = new JsonObject();
            profileData.addProperty("email", normalizedEmail);
            profileData.addProperty("username", username);          // username -> username
            profileData.addProperty("password_hash", password);     // password -> password_hash
            profileData.addProperty("full_name", fullName);         // fullName -> full_name
            profileData.addProperty("gender", gender);
            profileData.addProperty("date_of_birth", dateOfBirth);
            profileData.addProperty("weight", weight);
            profileData.addProperty("height", height);
            profileData.addProperty("fitness_level", fitnessLevel);

            String endpoint = "profiles?select=*";
            Request request = createSupabaseRequest(endpoint, "POST", profileData);

            Log.d("AuthRepository", "Отправка запроса на: " + endpoint);
            Log.d("AuthRepository", "JSON данные: " + profileData.toString());

            String response = executeRequest(request);
            Log.d("AuthRepository", "Ответ от сервера: " + response);

            JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
            if (jsonArray.size() > 0) {
                JsonObject createdProfile = jsonArray.get(0).getAsJsonObject();

                Profile profile = new Profile();

                // ПРАВИЛЬНОЕ ИЗВЛЕЧЕНИЕ ДАННЫХ ИЗ ОТВЕТА
                if (createdProfile.has("id") && !createdProfile.get("id").isJsonNull()) {
                    profile.setId(createdProfile.get("id").getAsLong());
                }

                if (createdProfile.has("email") && !createdProfile.get("email").isJsonNull()) {
                    profile.setEmail(createdProfile.get("email").getAsString());
                }

                // ВАЖНО: username из поля "username"
                if (createdProfile.has("username") && !createdProfile.get("username").isJsonNull()) {
                    profile.setUsername(createdProfile.get("username").getAsString());
                }

                // ВАЖНО: full_name из поля "full_name"
                if (createdProfile.has("full_name") && !createdProfile.get("full_name").isJsonNull()) {
                    profile.setFullName(createdProfile.get("full_name").getAsString());
                }

                if (createdProfile.has("fitness_level") && !createdProfile.get("fitness_level").isJsonNull()) {
                    profile.setFitnessLevel(createdProfile.get("fitness_level").getAsString());
                }

                if (createdProfile.has("weight") && !createdProfile.get("weight").isJsonNull()) {
                    profile.setWeight(createdProfile.get("weight").getAsDouble());
                }

                if (createdProfile.has("height") && !createdProfile.get("height").isJsonNull()) {
                    profile.setHeight(createdProfile.get("height").getAsDouble());
                }

                Log.d("AuthRepository", "=== ПРОФИЛЬ УСПЕШНО СОЗДАН ===");
                Log.d("AuthRepository", "ID: " + profile.getId());
                Log.d("AuthRepository", "Email: " + profile.getEmail());
                Log.d("AuthRepository", "Username: " + profile.getUsername());
                Log.d("AuthRepository", "FullName: " + profile.getFullName());
                Log.d("AuthRepository", "FitnessLevel: " + profile.getFitnessLevel());
                Log.d("AuthRepository", "Weight: " + profile.getWeight());
                Log.d("AuthRepository", "Height: " + profile.getHeight());

                return Resource.success(profile);
            } else {
                Log.e("AuthRepository", "ОШИБКА: Профиль не создан - пустой ответ от сервера");
                return Resource.error("Профиль не был создан", null);
            }

        } catch (Exception e) {
            Log.e("AuthRepository", "ОШИБКА РЕГИСТРАЦИИ: " + e.getMessage(), e);
            return Resource.error("Ошибка регистрации: " + e.getMessage(), null);
        }
    }

    // СИНХРОННЫЙ метод для входа - ИСПРАВЛЕННЫЙ ОТ JsonNull
    public Resource<Profile> signInSync(String email, String password) {
        try {
            String normalizedEmail = email.toLowerCase();

            Log.d("AuthRepository", "=== НАЧАЛО ВХОДА ===");
            Log.d("AuthRepository", "Email: " + normalizedEmail);

            String endpoint = "profiles?email=eq." + normalizedEmail + "&select=*";
            Request request = createSupabaseRequest(endpoint, "GET", null);

            Log.d("AuthRepository", "Отправка запроса на: " + endpoint);

            String response = executeRequest(request);
            Log.d("AuthRepository", "Ответ от сервера: " + response);

            JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
            if (jsonArray.size() > 0) {
                JsonObject profileData = jsonArray.get(0).getAsJsonObject();

                // ИСПРАВЛЕНИЕ: Проверяем, что password_hash не null
                String storedPassword = "";
                if (profileData.has("password_hash") && !profileData.get("password_hash").isJsonNull()) {
                    storedPassword = profileData.get("password_hash").getAsString();
                } else {
                    Log.e("AuthRepository", "ОШИБКА: password_hash is null или JsonNull");
                    return Resource.error("Ошибка: пароль не установлен в профиле", null);
                }

                Log.d("AuthRepository", "Сравнение паролей:");
                Log.d("AuthRepository", "Сохраненный пароль: " + storedPassword);
                Log.d("AuthRepository", "Введенный пароль: " + password);

                if (storedPassword.equals(password)) {
                    Profile profile = new Profile();

                    // ПРАВИЛЬНОЕ ИЗВЛЕЧЕНИЕ ДАННЫХ ИЗ ОТВЕТА
                    if (profileData.has("id") && !profileData.get("id").isJsonNull()) {
                        profile.setId(profileData.get("id").getAsLong());
                    }

                    if (profileData.has("email") && !profileData.get("email").isJsonNull()) {
                        profile.setEmail(profileData.get("email").getAsString());
                    }

                    // ВАЖНО: username из поля "username"
                    if (profileData.has("username") && !profileData.get("username").isJsonNull()) {
                        profile.setUsername(profileData.get("username").getAsString());
                    }

                    // ВАЖНО: full_name из поля "full_name"
                    if (profileData.has("full_name") && !profileData.get("full_name").isJsonNull()) {
                        profile.setFullName(profileData.get("full_name").getAsString());
                    }

                    if (profileData.has("fitness_level") && !profileData.get("fitness_level").isJsonNull()) {
                        profile.setFitnessLevel(profileData.get("fitness_level").getAsString());
                    }

                    if (profileData.has("weight") && !profileData.get("weight").isJsonNull()) {
                        profile.setWeight(profileData.get("weight").getAsDouble());
                    }

                    if (profileData.has("height") && !profileData.get("height").isJsonNull()) {
                        profile.setHeight(profileData.get("height").getAsDouble());
                    }

                    Log.d("AuthRepository", "=== ВХОД УСПЕШЕН ===");
                    Log.d("AuthRepository", "ID: " + profile.getId());
                    Log.d("AuthRepository", "Username: " + profile.getUsername());
                    Log.d("AuthRepository", "FullName: " + profile.getFullName());
                    Log.d("AuthRepository", "Email: " + profile.getEmail());

                    return Resource.success(profile);
                } else {
                    Log.e("AuthRepository", "ОШИБКА: Неверный пароль");
                    return Resource.error("Неверный пароль", null);
                }
            } else {
                Log.e("AuthRepository", "ОШИБКА: Пользователь не найден");
                return Resource.error("Пользователь не найден", null);
            }

        } catch (Exception e) {
            Log.e("AuthRepository", "ОШИБКА ВХОДА: " + e.getMessage(), e);
            return Resource.error("Ошибка сети: " + e.getMessage(), null);
        }
    }

    // Асинхронные методы
    public LiveData<Resource<Profile>> signUp(String email, String password, String username,
                                              String fullName, String gender, String dateOfBirth,
                                              double weight, double height, String fitnessLevel) {
        MutableLiveData<Resource<Profile>> result = new MutableLiveData<>();

        executor.execute(() -> {
            Resource<Profile> resource = signUpSync(email, password, username, fullName,
                    gender, dateOfBirth, weight, height, fitnessLevel);
            result.postValue(resource);
        });

        return result;
    }

    public LiveData<Resource<Profile>> signIn(String email, String password) {
        MutableLiveData<Resource<Profile>> result = new MutableLiveData<>();

        executor.execute(() -> {
            Resource<Profile> resource = signInSync(email, password);
            result.postValue(resource);
        });

        return result;
    }

    // Проверка существования пользователя
    public LiveData<Resource<Boolean>> checkUserExists(String email) {
        MutableLiveData<Resource<Boolean>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                String normalizedEmail = email.toLowerCase();
                String endpoint = "profiles?email=eq." + normalizedEmail + "&select=id";
                Request request = createSupabaseRequest(endpoint, "GET", null);
                String response = executeRequest(request);

                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                boolean userExists = jsonArray.size() > 0;

                Log.d("AuthRepository", "Проверка пользователя " + normalizedEmail + ": " + userExists);
                result.postValue(Resource.success(userExists));

            } catch (Exception e) {
                Log.e("AuthRepository", "Ошибка проверки пользователя: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка проверки: " + e.getMessage(), null));
            }
        });

        return result;
    }
}
