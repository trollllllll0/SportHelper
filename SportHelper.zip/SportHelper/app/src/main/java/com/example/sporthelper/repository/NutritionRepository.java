package com.example.sporthelper.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.NutritionLog;
import com.example.sporthelper.model.Resource;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import okhttp3.Request;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NutritionRepository extends BaseRepository {
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Gson gson = new Gson();

    // Добавляем конструктор с Context
    public NutritionRepository(Context context) {
        super(context);
    }

    public LiveData<Resource<List<NutritionLog>>> getNutritionLogs(Long userId, String date) {
        MutableLiveData<Resource<List<NutritionLog>>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));

                String endpoint = "nutrition_logs?user_id=eq." + userId + "&log_date=eq." + date + "&select=*";
                Request request = createSupabaseRequest(endpoint, "GET", null);
                String response = executeRequest(request);

                JsonArray jsonArray = gson.fromJson(response, JsonArray.class);
                List<NutritionLog> logs = new ArrayList<>();

                for (int i = 0; i < jsonArray.size(); i++) {
                    JsonObject logObj = jsonArray.get(i).getAsJsonObject();
                    NutritionLog log = new NutritionLog();
                    log.setId(logObj.get("id").getAsLong());
                    log.setUserId(logObj.get("user_id").getAsLong());
                    log.setLogDate(logObj.get("log_date").getAsString());
                    log.setMealType(logObj.get("meal_type").getAsString());
                    log.setFoodName(logObj.get("food_name").getAsString());
                    log.setCalories(logObj.get("calories").getAsInt());

                    if (logObj.has("protein") && !logObj.get("protein").isJsonNull()) {
                        log.setProtein(logObj.get("protein").getAsDouble());
                    }
                    if (logObj.has("carbs") && !logObj.get("carbs").isJsonNull()) {
                        log.setCarbs(logObj.get("carbs").getAsDouble());
                    }
                    if (logObj.has("fat") && !logObj.get("fat").isJsonNull()) {
                        log.setFat(logObj.get("fat").getAsDouble());
                    }

                    logs.add(log);
                }

                result.postValue(Resource.success(logs));

            } catch (Exception e) {
                Log.e("NutritionRepository", "Ошибка загрузки питания: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка загрузки: " + e.getMessage(), createMockNutritionLogs(userId)));
            }
        });

        return result;
    }

    public LiveData<Resource<String>> analyzeFoodPhoto(byte[] imageData) {
        MutableLiveData<Resource<String>> result = new MutableLiveData<>();

        executor.execute(() -> {
            try {
                result.postValue(Resource.loading(null));
                Thread.sleep(2500);

                String analysis = "Распознанные продукты:\n• Банан - 89 ккал\n• Яблоко - 52 ккал\n• Овсянка - 150 ккал\nОбщая калорийность: 291 ккал";
                result.postValue(Resource.success(analysis));

            } catch (Exception e) {
                Log.e("NutritionRepository", "Ошибка анализа фото: " + e.getMessage(), e);
                result.postValue(Resource.error("Ошибка анализа фото", null));
            }
        });

        return result;
    }

    private List<NutritionLog> createMockNutritionLogs(Long userId) {
        List<NutritionLog> logs = new ArrayList<>();

        logs.add(new NutritionLog(1L, userId, "2024-01-15", "breakfast",
                "Овсянка с бананом", 350, 12.5, 60.2, 8.1));

        logs.add(new NutritionLog(2L, userId, "2024-01-15", "lunch",
                "Куриная грудка с гречкой", 450, 35.0, 45.0, 12.0));

        return logs;
    }
}
