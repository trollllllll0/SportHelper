package com.example.sporthelper.model;

public class Workout {
    private Long id;
    private Long userId;
    private String workoutDate;
    private String workoutName;
    private Integer durationMinutes;
    private Integer caloriesBurned;
    private String notes;

    public Workout() {}

    public Workout(Long id, Long userId, String workoutName, String workoutDate,
                   Integer durationMinutes, Integer caloriesBurned, String notes) {
        this.id = id;
        this.userId = userId;
        this.workoutName = workoutName;
        this.workoutDate = workoutDate;
        this.durationMinutes = durationMinutes;
        this.caloriesBurned = caloriesBurned;
        this.notes = notes;
    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getWorkoutDate() { return workoutDate; }
    public void setWorkoutDate(String workoutDate) { this.workoutDate = workoutDate; }

    public String getWorkoutName() { return workoutName; }
    public void setWorkoutName(String workoutName) { this.workoutName = workoutName; }

    public Integer getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(Integer durationMinutes) { this.durationMinutes = durationMinutes; }

    public Integer getCaloriesBurned() { return caloriesBurned; }
    public void setCaloriesBurned(Integer caloriesBurned) { this.caloriesBurned = caloriesBurned; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}