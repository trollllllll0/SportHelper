package com.example.sporthelper.activity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sporthelper.R;
import com.example.sporthelper.adapter.NutritionAdapter;
import com.example.sporthelper.model.NutritionLog;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.viewmodel.NutritionViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NutritionActivity extends AppCompatActivity {
    private NutritionViewModel nutritionViewModel;
    private NutritionAdapter nutritionAdapter;
    private Long currentUserId = 1L;

    // View variables
    private RecyclerView nutritionRecyclerView;
    private LinearLayout emptyState;
    private ImageButton refreshButton, prevDayButton, nextDayButton;
    private MaterialButton addNutritionButton, analyzePhotoButton;
    private MaterialToolbar toolbar;
    private TextView currentDateText, totalCaloriesText, totalProteinText, totalFatText, totalCarbsText;

    // Date management
    private Calendar currentDate;
    private SimpleDateFormat dateFormatter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition);

        initViews();
        initDate();
        initViewModels();
        setupRecyclerView();
        setupUI();
        loadNutritionLogs();
    }

    private void initViews() {
        nutritionRecyclerView = findViewById(R.id.nutritionRecyclerView);
        emptyState = findViewById(R.id.emptyState);
        refreshButton = findViewById(R.id.refreshButton);
        prevDayButton = findViewById(R.id.prevDayButton);
        nextDayButton = findViewById(R.id.nextDayButton);
        addNutritionButton = findViewById(R.id.addNutritionButton);
        analyzePhotoButton = findViewById(R.id.analyzePhotoButton);
        toolbar = findViewById(R.id.toolbar);

        currentDateText = findViewById(R.id.currentDateText);
        totalCaloriesText = findViewById(R.id.totalCaloriesText);
        totalProteinText = findViewById(R.id.totalProteinText);
        totalFatText = findViewById(R.id.totalFatText);
        totalCarbsText = findViewById(R.id.totalCarbsText);
    }

    private void initDate() {
        currentDate = Calendar.getInstance();
        dateFormatter = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        updateDateText();
    }

    private void initViewModels() {
        nutritionViewModel = new ViewModelProvider(this).get(NutritionViewModel.class);
    }

    private void setupRecyclerView() {
        nutritionAdapter = new NutritionAdapter(null);
        nutritionRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        nutritionRecyclerView.setAdapter(nutritionAdapter);
    }

    private void setupUI() {
        // Устанавливаем заголовок
        if (toolbar != null) {
            toolbar.setTitle("Питание");
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }

        refreshButton.setOnClickListener(v -> {
            loadNutritionLogs();
            Toast.makeText(NutritionActivity.this, "Обновление...", Toast.LENGTH_SHORT).show();
        });

        prevDayButton.setOnClickListener(v -> {
            currentDate.add(Calendar.DAY_OF_MONTH, -1);
            updateDateText();
            loadNutritionLogs();
        });

        nextDayButton.setOnClickListener(v -> {
            currentDate.add(Calendar.DAY_OF_MONTH, 1);
            updateDateText();
            loadNutritionLogs();
        });

        addNutritionButton.setOnClickListener(v -> showAddNutritionDialog());
        analyzePhotoButton.setOnClickListener(v -> analyzeFoodPhoto());
    }

    private void updateDateText() {
        String dateString = dateFormatter.format(currentDate.getTime());
        Calendar today = Calendar.getInstance();

        if (isSameDay(currentDate, today)) {
            currentDateText.setText("Сегодня");
        } else {
            currentDateText.setText(dateString);
        }
    }

    private boolean isSameDay(Calendar cal1, Calendar cal2) {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }

    private void loadNutritionLogs() {
        String selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                .format(currentDate.getTime());

        nutritionViewModel.loadNutritionLogs(currentUserId, selectedDate);
        nutritionViewModel.getNutritionLogs().observe(this, resource -> {
            if (resource != null) {
                switch (resource.status) {
                    case SUCCESS:
                        List<NutritionLog> logs = resource.data;
                        nutritionAdapter.updateNutritionLogs(logs);
                        showEmptyState(logs == null || logs.isEmpty());
                        updateNutritionStats(logs);
                        break;
                    case ERROR:
                        showEmptyState(true);
                        showError("Ошибка загрузки данных питания");
                        break;
                }
            }
        });
    }

    private void updateNutritionStats(List<NutritionLog> logs) {
        if (logs == null || logs.isEmpty()) {
            totalCaloriesText.setText("0");
            totalProteinText.setText("0г");
            totalFatText.setText("0г");
            totalCarbsText.setText("0г");
            return;
        }

        int totalCalories = 0;
        double totalProtein = 0;
        double totalFat = 0;
        double totalCarbs = 0;

        for (NutritionLog log : logs) {
            if (log.getCalories() != null) totalCalories += log.getCalories();
            if (log.getProtein() != null) totalProtein += log.getProtein();
            if (log.getFat() != null) totalFat += log.getFat();
            if (log.getCarbs() != null) totalCarbs += log.getCarbs();
        }

        totalCaloriesText.setText(String.valueOf(totalCalories));
        totalProteinText.setText(String.format(Locale.getDefault(), "%.1fг", totalProtein));
        totalFatText.setText(String.format(Locale.getDefault(), "%.1fг", totalFat));
        totalCarbsText.setText(String.format(Locale.getDefault(), "%.1fг", totalCarbs));
    }

    private void analyzeFoodPhoto() {
        Toast.makeText(this, "Анализ фото еды...", Toast.LENGTH_SHORT).show();
    }

    private void showAddNutritionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Добавить прием пищи")
                .setMessage("Функция добавления в разработке")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showEmptyState(boolean show) {
        emptyState.setVisibility(show ? View.VISIBLE : View.GONE);
        nutritionRecyclerView.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.nutrition_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == android.R.id.home) {
            onBackPressed();
            return true;
        } else if (itemId == R.id.action_refresh) {
            loadNutritionLogs();
            return true;
        } else if (itemId == R.id.action_calories_calc) {
            showComingSoonDialog("Калькулятор калорий");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showComingSoonDialog(String feature) {
        new AlertDialog.Builder(this)
                .setTitle("Скоро будет!")
                .setMessage("Функция \"" + feature + "\" находится в разработке")
                .setPositiveButton("OK", null)
                .show();
    }
}
