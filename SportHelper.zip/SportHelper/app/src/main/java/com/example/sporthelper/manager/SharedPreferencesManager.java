package com.example.sporthelper.manager;

import android.content.Context;
import android.content.SharedPreferences;
import com.example.sporthelper.model.Profile;
import com.google.gson.Gson;

public class SharedPreferencesManager {
    private static final String PREF_NAME = "SportHelperPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_PROFILE = "userProfile";
    private static final String KEY_USER_ID = "userId";

    private static SharedPreferencesManager instance;
    private final SharedPreferences sharedPreferences;
    private final Gson gson;

    private SharedPreferencesManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public static synchronized SharedPreferencesManager getInstance(Context context) {
        if (instance == null) {
            instance = new SharedPreferencesManager(context);
        }
        return instance;
    }

    public SharedPreferences getSharedPreferences() {
        return sharedPreferences;
    }

    public void setLoggedIn(boolean isLoggedIn) {
        sharedPreferences.edit().putBoolean(KEY_IS_LOGGED_IN, isLoggedIn).apply();
    }

    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public void saveUserProfile(Profile profile) {
        if (profile != null) {
            String profileJson = gson.toJson(profile);
            sharedPreferences.edit()
                    .putString(KEY_USER_PROFILE, profileJson)
                    .putLong(KEY_USER_ID, profile.getId() != null ? profile.getId() : -1)
                    .apply();
        }
    }

    public Profile getUserProfile() {
        String profileJson = sharedPreferences.getString(KEY_USER_PROFILE, null);
        if (profileJson != null) {
            return gson.fromJson(profileJson, Profile.class);
        }
        return null;
    }

    public Long getUserId() {
        return sharedPreferences.getLong(KEY_USER_ID, -1);
    }

    public void logout() {
        sharedPreferences.edit()
                .remove(KEY_IS_LOGGED_IN)
                .remove(KEY_USER_PROFILE)
                .remove(KEY_USER_ID)
                .apply();
    }
}
