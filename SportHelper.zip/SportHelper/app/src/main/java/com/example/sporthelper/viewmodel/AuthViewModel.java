package com.example.sporthelper.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.sporthelper.model.Profile;
import com.example.sporthelper.model.Resource;
import com.example.sporthelper.repository.AuthRepository;

public class AuthViewModel extends AndroidViewModel {
    private AuthRepository authRepository;
    private MutableLiveData<Resource<Profile>> authResult = new MutableLiveData<>();

    public AuthViewModel(@NonNull Application application) {
        super(application);
        this.authRepository = new AuthRepository(application.getApplicationContext());
    }

    public void signUp(String email, String password, String username,
                       String fullName, String gender, String dateOfBirth,
                       double weight, double height, String fitnessLevel) {
        authResult.setValue(Resource.loading(null));
        authRepository.signUp(email, password, username, fullName, gender,
                        dateOfBirth, weight, height, fitnessLevel)
                .observeForever(result -> {
                    authResult.postValue(result);
                });
    }

    public void signIn(String email, String password) {
        authResult.setValue(Resource.loading(null));
        authRepository.signIn(email, password).observeForever(result -> {
            authResult.postValue(result);
        });
    }

    public LiveData<Resource<Profile>> getAuthResult() {
        return authResult;
    }
}
